<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="water" tilewidth="32" tileheight="32" tilecount="126" columns="14">
 <image source="water.png" width="474" height="316"/>
</tileset>
